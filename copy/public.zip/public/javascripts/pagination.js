/* Pagination Script start */
		$(function() {
			$("#pagination").paginate({
                                href : '',         
                                count 		: 50,
				start 		: 3,
				display     : 5,
				border					: false,
				text_color  			: '',
				background_color    	: '',	
				text_hover_color  		: '',
				background_hover_color	: ''
			});
		});
/* Pagination Script end */

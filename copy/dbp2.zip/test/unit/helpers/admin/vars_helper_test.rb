require 'test_helper'

class Admin::VarsHelperTest < ActionView::TestCase
end

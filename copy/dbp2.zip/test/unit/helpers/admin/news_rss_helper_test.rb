require 'test_helper'

class Admin::NewsRssHelperTest < ActionView::TestCase
end

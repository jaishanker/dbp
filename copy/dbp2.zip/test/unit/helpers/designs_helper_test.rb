require 'test_helper'

class DesignsHelperTest < ActionView::TestCase
end

require 'test_helper'

class LearningsHelperTest < ActionView::TestCase
end

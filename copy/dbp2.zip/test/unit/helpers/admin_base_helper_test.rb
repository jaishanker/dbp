require 'test_helper'

class AdminBaseHelperTest < ActionView::TestCase
end

require 'test_helper'

class ContestHelperTest < ActionView::TestCase
end

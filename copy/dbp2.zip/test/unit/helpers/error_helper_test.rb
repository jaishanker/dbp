require 'test_helper'

class ErrorHelperTest < ActionView::TestCase
end

class AddCswpWeldmentProfiles < ActiveRecord::Migration
  def self.up
    add_column :profiles, :cswp_weldment_prof, :string, :limit => 5      
  end

  def self.down
    remove_column :profiles, :cswp_weldment_prof
  end
end

class ChangeEmbedCodeType < ActiveRecord::Migration
  def self.up
    change_column :learnings, :embed_code, :text    
  end

  def self.down
    change_column :learnings, :embed_code, :string
  end
end

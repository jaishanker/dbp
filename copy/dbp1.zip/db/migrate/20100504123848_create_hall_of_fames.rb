class CreateHallOfFames < ActiveRecord::Migration
  def self.up
#    create_table :hall_of_fames do |t|
#      t.column :name,                  :string, :limit => 100
#      t.column :email,                 :string, :limit => 100
#      t.column :certification,         :string, :limit => 100
#      t.column :simulation_no,         :string, :limit => 100
#      t.column :certification_date,    :date
#      t.column :status,                :integer, :limit => 4
#      t.column :user_id,               :integer
#      t.timestamps
#    end
  end
  
  def self.down
#    drop_table :hall_of_fames
  end
end

class AddTags < ActiveRecord::Migration
  def self.up
     add_column :designs, :tags, :string
  end

  def self.down
     remove_column :designs, :tags
  end
end

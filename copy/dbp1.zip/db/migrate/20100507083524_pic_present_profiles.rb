class PicPresentProfiles < ActiveRecord::Migration
  def self.up
    add_column :profiles, :pic_present, :boolean   
  end

  def self.down
    remove_column :profiles, :pic_present
  end
end

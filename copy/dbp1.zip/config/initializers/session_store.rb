# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_dbp_session',
  :secret      => '7aa11e49b9a61b98b8f292b9ce5f9a254bd7c113718d38cc26b47d7aff7f107518fc4753b9de20ce25c1928428cf8e575c5d3d5b7eedee515ea29cb087ed7a87'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
